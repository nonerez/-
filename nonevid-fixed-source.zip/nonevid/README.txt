nonevid - Android prototype

This is an early UI prototype. The launcher/app display name is nonevid.

Current prototype areas:
- Home: movie catalog and local watch-reward counter
- Explore: short-video feed mockup with demo clips, likes, follow toggles, comments placeholder and upload entry point
- Wallet: local token balance and watch statistics
- Profile: account/profile options
- Settings: appearance, notifications, security, help and about (opens the same local pages as Profile)

Important:
- Explore uses public sample clips with fictional usernames and like counts, not real uploaded/streamed videos.
- Upload, comments, follows, sharing and social data are not connected to a backend.
- Login, identity check, 2-step toggle, notifications and rewards are local prototype behavior only. Do not use this build for real accounts, payments or valuable tokens.
- The existing applicationId/package is retained so this remains compatible with the prior prototype installation. The visible app name is nonevid.

How to build
- Android Studio (Koala or newer, JDK 17): Open this folder, wait for Gradle sync, Run. APK: Build > Build APK(s).
- Without a PC: push this folder (or the zip) to a GitHub repo; .github/workflows/build.yml builds app-debug.apk
  (Actions tab > latest run > Artifacts > nonevid-debug-apk).
- Toolchain: Gradle 8.7+, AGP 8.5.2, Kotlin 1.9.24, Compose compiler 1.5.14, compileSdk 34, minSdk 24.
- For a quick reward test, lower REWARD_SEC at the top of MainActivity.kt (e.g. 20).
