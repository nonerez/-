package com.example.moviehub

import android.app.Activity
import android.content.Context
import android.content.SharedPreferences
import android.view.WindowManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.media3.ui.AspectRatioFrameLayout
import kotlinx.coroutines.delay
import java.security.MessageDigest
import java.util.Locale
import kotlin.reflect.KProperty

// ===== تنظیمات پاداش (برای تست سریع، REWARD_SEC را مثلاً 20 بگذارید) =====
const val REWARD_SEC = 900L      // هر ۱۵ دقیقه
const val REWARD_TOKENS = 1000L
const val VIDEO_URL = "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4"

data class Movie(val id: Int, val title: String, val cat: String, val year: Int, val desc: String, val color: Color)

val cats = listOf("همه", "ترسناک", "هیجانی", "کمدی", "درام", "علمی‌تخیلی", "انیمیشن")
val movies = listOf(
    Movie(1, "شب خاموش", "ترسناک", 2023, "گروهی دوست در خانه‌ای متروک گرفتار می‌شوند.", Color(0xFF4A148C)),
    Movie(2, "سایه‌ها", "ترسناک", 2022, "رازی قدیمی در یک روستای دورافتاده بیدار می‌شود.", Color(0xFF311B92)),
    Movie(3, "تعقیب", "هیجانی", 2024, "یک کارآگاه در مسابقه‌ای نفس‌گیر با زمان.", Color(0xFFB71C1C)),
    Movie(4, "خط قرمز", "هیجانی", 2021, "عملیاتی پرخطر که هیچ‌کس نباید از آن باخبر شود.", Color(0xFFD84315)),
    Movie(5, "دورهمی", "کمدی", 2023, "یک مهمانی ساده که همه‌چیز را به هم می‌ریزد.", Color(0xFFF9A825)),
    Movie(6, "شانس آوردیم", "کمدی", 2020, "دو همسایه و یک سوءتفاهم بزرگ.", Color(0xFFEF6C00)),
    Movie(7, "خانه‌ی پدری", "درام", 2022, "بازگشت به خانه، بازگشت به خاطرات.", Color(0xFF00695C)),
    Movie(8, "فصل آخر", "درام", 2024, "داستان خانواده‌ای در آستانه‌ی تغییر.", Color(0xFF2E7D32)),
    Movie(9, "مدار صفر", "علمی‌تخیلی", 2025, "سفری به آن‌سوی زمان و مکان.", Color(0xFF1565C0)),
    Movie(10, "ستاره‌ی دور", "علمی‌تخیلی", 2023, "آخرین مأموریت یک فضانورد.", Color(0xFF0277BD)),
    Movie(11, "جنگل جادو", "انیمیشن", 2024, "ماجراجویی دوستان کوچک در جنگلی افسانه‌ای.", Color(0xFF6A1B9A)),
    Movie(12, "ماه‌پرواز", "انیمیشن", 2022, "پسری که می‌خواهد به ماه برسد.", Color(0xFFAD1457)),
)
val accents = listOf(0xFFE50914, 0xFF1E88E5, 0xFF43A047, 0xFF8E24AA, 0xFFFB8C00, 0xFF00ACC1, 0xFFD81B60, 0xFF6D4C41)
val notifTypes = listOf(
    "new" to "فیلم‌های جدید", "episode" to "قسمت جدید سریال‌های ذخیره‌شده",
    "reward" to "دریافت توکن", "offer" to "پیشنهادهای ویژه", "security" to "هشدارهای امنیتی",
)

// ===== ذخیره‌سازی ساده =====
class Pref<T : Any>(private val sp: SharedPreferences, private val k: String, d: T) {
    @Suppress("UNCHECKED_CAST")
    private var st by mutableStateOf(when (d) {
        is Long -> sp.getLong(k, d); is Boolean -> sp.getBoolean(k, d)
        is Int -> sp.getInt(k, d); else -> sp.getString(k, d as String)
    } as T)
    operator fun getValue(r: Any?, p: KProperty<*>): T = st
    operator fun setValue(r: Any?, p: KProperty<*>, v: T) {
        st = v
        sp.edit().apply {
            when (v) {
                is Long -> putLong(k, v); is Boolean -> putBoolean(k, v)
                is Int -> putInt(k, v); else -> putString(k, v as String)
            }
        }.apply()
    }
}

class Store(c: Context) {
    private val sp = c.getSharedPreferences("app", 0)
    var tokens by Pref(sp, "tokens", 0L)
    var watchSec by Pref(sp, "watch", 0L)
    var loggedIn by Pref(sp, "in", false)
    var name by Pref(sp, "name", "")
    var phone by Pref(sp, "phone", "")
    var accounts by Pref(sp, "accounts", "")
    var verified by Pref(sp, "verified", false)
    var themeMode by Pref(sp, "theme", 0)
    var accent by Pref(sp, "accent", accents[0].toInt())
    var amoled by Pref(sp, "amoled", false)
    var notifs by Pref(sp, "notifs", "new,episode,reward,security")
    var savedIds by Pref(sp, "saved", "")
    var pinOn by Pref(sp, "pinOn", false)
    var pin by Pref(sp, "pin", "")
    var twoStep by Pref(sp, "twoStep", false)
    var secureScreen by Pref(sp, "secure", false)

    /** مقایسه‌ی رمز؛ مقدار قدیمیِ ذخیره‌شده به‌صورت متن ساده هم پذیرفته می‌شود (سازگاری با نسخه‌ی قبل) */
    fun checkPin(input: String) = pin.isNotEmpty() && (pin == hashPin(input) || pin == input)

    /** هر ثانیه پخش یک‌بار صدا زده می‌شود؛ اگر پاداش داده شد true برمی‌گرداند */
    fun tick(): Boolean {
        watchSec += 1
        if (watchSec % REWARD_SEC == 0L) { tokens += REWARD_TOKENS; return true }
        return false
    }
}

fun hashPin(p: String): String =
    MessageDigest.getInstance("SHA-256").digest("nonevid:$p".toByteArray()).joinToString("") { "%02x".format(it) }

fun has(s: String, k: String) = s.split(",").contains(k)
fun toggle(s: String, k: String) = s.split(",").filter { it.isNotEmpty() }.let { if (k in it) it - k else it + k }.joinToString(",")

fun validNationalCode(c: String): Boolean {
    if (!Regex("\\d{10}").matches(c) || c.all { it == c[0] }) return false
    val r = (0..8).sumOf { (c[it] - '0') * (10 - it) } % 11
    val k = c[9] - '0'
    return if (r < 2) k == r else k == 11 - r
}
fun validPhone(p: String) = Regex("^09\\d{9}$").matches(p)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val store = Store(this)
        setContent { App(store) }
    }
}

@Composable
fun App(st: Store) {
    val dark = when (st.themeMode) { 1 -> false; 2 -> true; else -> isSystemInDarkTheme() }
    val acc = Color(st.accent)
    val scheme = if (dark) {
        if (st.amoled) darkColorScheme(primary = acc, background = Color.Black, surface = Color.Black)
        else darkColorScheme(primary = acc)
    } else lightColorScheme(primary = acc)
    val act = LocalContext.current as Activity
    LaunchedEffect(st.secureScreen) {
        if (st.secureScreen) act.window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        else act.window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
    }
    MaterialTheme(colorScheme = scheme) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Surface(Modifier.fillMaxSize()) {
                var unlocked by remember { mutableStateOf(!st.pinOn) }
                when {
                    !unlocked -> PinScreen(st) { unlocked = true }
                    !st.loggedIn -> LoginScreen(st)
                    else -> MainScreen(st)
                }
            }
        }
    }
}

@Composable
fun PinScreen(st: Store, onOk: () -> Unit) {
    var v by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(32.dp), Arrangement.Center, Alignment.CenterHorizontally) {
        Icon(Icons.Default.Lock, null, Modifier.size(56.dp))
        Spacer(Modifier.height(16.dp))
        Text("رمز ورود را وارد کنید", style = MaterialTheme.typography.titleLarge)
        OutlinedTextField(v, { val d = it.filter(Char::isDigit).take(4); v = d; if (d.length == 4 && st.checkPin(d)) onOk() },
            visualTransformation = PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
            isError = v.length == 4 && !st.checkPin(v), singleLine = true, modifier = Modifier.padding(top = 16.dp))
    }
}

@Composable
fun LoginScreen(st: Store) {
    val ctx = LocalContext.current
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    fun login(n: String, p: String) {
        st.name = n; st.phone = p; st.loggedIn = true
        if (!st.accounts.split(";").contains("$n|$p")) st.accounts = (st.accounts.split(";").filter { it.contains("|") } + "$n|$p").joinToString(";")
    }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Spacer(Modifier.height(32.dp))
        Text("به nonevid خوش آمدید", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        st.accounts.split(";").filter { it.contains("|") }.forEach { a ->
            val parts = a.split("|")
            val n = parts[0]
            val p = parts[1]
            OutlinedCard(Modifier.fillMaxWidth().clickable { login(n, p) }) {
                ListItem(headlineContent = { Text(n) }, supportingContent = { Text(p) }, leadingContent = { Icon(Icons.Default.AccountCircle, null) })
            }
        }
        OutlinedTextField(name, { name = it }, label = { Text("نام کاربری") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(phone, { phone = it }, label = { Text("شماره تماس (09...)") }, singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), modifier = Modifier.fillMaxWidth())
        Button({
            val cleanName = name.replace(Regex("[;|]"), " ").trim()
            if (cleanName.isEmpty() || !validPhone(phone)) Toast.makeText(ctx, "نام و شماره معتبر وارد کنید", Toast.LENGTH_SHORT).show()
            else login(cleanName, phone)
        }, Modifier.fillMaxWidth()) { Text("ورود / ساخت حساب") }
    }
}

@Composable
fun MainScreen(st: Store) {
    var tab by remember { mutableIntStateOf(0) }
    var playing by remember { mutableStateOf<Movie?>(null) }
    BackHandler(playing != null) { playing = null }
    val m = playing
    if (m != null) { PlayerScreen(st, m) { playing = null }; return }
    Scaffold(
        containerColor = Color(0xFF080710),
        contentColor = Color.White,
        bottomBar = {
            NavigationBar(containerColor = Color(0xFF100D1B), contentColor = Color.White) {
                val items = listOf(
                    Triple("خانه", Icons.Default.Home, 0),
                    Triple("اکسپلور", Icons.Default.Explore, 1),
                    Triple("کیف پول", Icons.Default.AccountBalanceWallet, 2),
                    Triple("پروفایل", Icons.Default.Person, 3),
                    Triple("تنظیمات", Icons.Default.Settings, 4)
                )
                items.forEach { (label, icon, index) ->
                    NavigationBarItem(
                        selected = tab == index,
                        onClick = { tab = index },
                        icon = { Icon(icon, contentDescription = label) },
                        label = { Text(label) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color(0xFFB45CFF), selectedTextColor = Color(0xFFB45CFF),
                            indicatorColor = Color(0xFF32134D), unselectedIconColor = Color(0xFFAAA5B8),
                            unselectedTextColor = Color(0xFFAAA5B8)
                        )
                    )
                }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> HomeScreen(st) { playing = it }
                1 -> ExploreScreen()
                2 -> WalletScreen(st)
                3 -> ProfileScreen(st)
                else -> SettingsScreen(st)
            }
        }
    }
}

private data class ShortClip(
    val user: String,
    val caption: String,
    val likes: Int,
    val url: String
)

private val demoClips = listOf(
    ShortClip("cinema_fan", "یه ماجراجویی سینمایی؛ صدا رو روشن کن 🎬", 12400,
        "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4"),
    ShortClip("movie_daily", "چند ثانیه هیجان خالص 🍿", 8900,
        "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4"),
    ShortClip("arman_edit", "وقتی تصویر خودش داستان رو تعریف می‌کنه ✨", 5620,
        "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyrides.mp4"),
    ShortClip("cinema_world", "یه قاب متفاوت از دنیای فیلم‌ها 🌌", 7100,
        "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerMeltdowns.mp4"),
    ShortClip("film_zone", "پیشنهاد امروز برای عاشقای تصویر 🎥", 10300,
        "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4")
)

@OptIn(UnstableApi::class)
@Composable
fun ExploreScreen() {
    val ctx = LocalContext.current
    var current by remember { mutableIntStateOf(0) }
    var liked by remember { mutableStateOf(setOf<Int>()) }
    var followed by remember { mutableStateOf(setOf<String>()) }
    var commentsOpen by remember { mutableStateOf(false) }
    var uploadOpen by remember { mutableStateOf(false) }
    var dragAmount by remember { mutableFloatStateOf(0f) }
    val clip = demoClips[current]

    val exo = remember(current) {
        ExoPlayer.Builder(ctx).build().apply {
            setMediaItem(MediaItem.fromUri(clip.url))
            repeatMode = Player.REPEAT_MODE_ONE
            prepare()
            playWhenReady = true
        }
    }
    DisposableEffect(exo) {
        onDispose { exo.release() }
    }
    PauseOnBackground(exo)
    val failed = rememberPlayerFailed(exo)

    Box(
        Modifier.fillMaxSize()
            .background(Color.Black)
            .pointerInput(current) {
                detectVerticalDragGestures(
                    onVerticalDrag = { _, amount -> dragAmount += amount },
                    onDragEnd = {
                        if (dragAmount < -45f) current = (current + 1) % demoClips.size
                        else if (dragAmount > 45f) current = (current - 1 + demoClips.size) % demoClips.size
                        dragAmount = 0f
                    },
                    onDragCancel = { dragAmount = 0f }
                )
            }
    ) {
        AndroidView(
            factory = { viewContext ->
                PlayerView(viewContext).apply {
                    player = exo
                    useController = false
                    resizeMode = AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                    setShutterBackgroundColor(android.graphics.Color.BLACK)
                }
            },
            update = { it.player = exo },
            modifier = Modifier.fillMaxSize()
        )

        if (failed.value) PlayerError(Modifier.align(Alignment.Center), Color.White) { exo.prepare(); exo.play() }

        // خوانایی متن و کنترل‌ها روی تصویر ویدیو
        Box(
            Modifier.fillMaxSize().background(
                brush = androidx.compose.ui.graphics.Brush.verticalGradient(
                    0f to Color(0x66000000),
                    0.42f to Color.Transparent,
                    1f to Color(0xCC05030A)
                )
            )
        )

        Row(
            Modifier.align(Alignment.TopCenter).fillMaxWidth().padding(horizontal = 18.dp, vertical = 18.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("nonevid", color = Color.White, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.ExtraBold)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("ویدیوهای کوتاه", color = Color.White, style = MaterialTheme.typography.titleMedium)
                IconButton(onClick = { uploadOpen = true }) {
                    Icon(Icons.Default.AddCircle, "آپلود ویدیو", tint = Color(0xFFB45CFF), modifier = Modifier.size(30.dp))
                }
            }
        }

        Row(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(start = 18.dp, end = 12.dp, bottom = 26.dp),
            verticalAlignment = Alignment.Bottom
        ) {
            Column(Modifier.weight(1f)) {
                Text("@${clip.user}", color = Color.White, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text(clip.caption, color = Color.White, style = MaterialTheme.typography.bodyLarge)
                Spacer(Modifier.height(12.dp))
                OutlinedButton(
                    onClick = { followed = if (clip.user in followed) followed - clip.user else followed + clip.user },
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFB45CFF))
                ) {
                    Text(if (clip.user in followed) "دنبال می‌کنی" else "+ دنبال کردن", color = Color.White)
                }
                Text("نمونه نمایشی  •  ${current + 1} از ${demoClips.size}  •  برای ویدیوی بعدی به بالا بکش", color = Color.LightGray, style = MaterialTheme.typography.labelSmall)
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                IconButton(onClick = { liked = if (current in liked) liked - current else liked + current }) {
                    Icon(
                        if (current in liked) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                        null,
                        tint = if (current in liked) Color(0xFFFF4D8D) else Color.White,
                        modifier = Modifier.size(32.dp)
                    )
                }
                Text(String.format(Locale.US, "%.1fK", (clip.likes + if (current in liked) 1 else 0) / 1000.0), color = Color.White)
                IconButton(onClick = { commentsOpen = true }) {
                    Icon(Icons.Default.ChatBubbleOutline, null, tint = Color.White, modifier = Modifier.size(29.dp))
                }
                IconButton(onClick = {
                    val send = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(android.content.Intent.EXTRA_TEXT, "ویدیوی نمونه در nonevid")
                    }
                    ctx.startActivity(android.content.Intent.createChooser(send, "اشتراک‌گذاری"))
                }) {
                    Icon(Icons.Default.Share, null, tint = Color.White, modifier = Modifier.size(28.dp))
                }
            }
        }
    }

    if (commentsOpen) AlertDialog(
        onDismissRequest = { commentsOpen = false },
        confirmButton = { TextButton(onClick = { commentsOpen = false }) { Text("بستن") } },
        title = { Text("نظرات") },
        text = { Text("این ویدیو نمونه است؛ بخش نظرات در نسخه نمایشی آماده اتصال به سرور است.") }
    )
    if (uploadOpen) AlertDialog(
        onDismissRequest = { uploadOpen = false },
        confirmButton = { TextButton(onClick = { uploadOpen = false }) { Text("متوجه شدم") } },
        title = { Text("آپلود ویدیو") },
        text = { Text("امکان انتخاب و انتشار واقعی ویدیو در مرحله بعد به این بخش اضافه می‌شود.") }
    )
}

@Composable
fun SettingsScreen(st: Store) {
    var sub by remember { mutableStateOf("") }
    var info by remember { mutableStateOf("") }
    val back = { sub = "" }
    when (sub) {
        "theme" -> SubPage("تنظیمات ظاهری", back) { Appearance(st) }
        "notif" -> SubPage("اعلان‌ها", back) { Notifications(st) }
        "security" -> SubPage("امنیت و حریم خصوصی", back) { Security(st) }
        else -> Column(Modifier.fillMaxSize().background(Color(0xFF080710)).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("تنظیمات", color = Color.White, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF171322))) {
                Column(Modifier.padding(8.dp)) {
                    NavRow(Icons.Default.Palette, "تنظیمات ظاهری", "تم و رنگ برنامه") { sub = "theme" }
                    NavRow(Icons.Default.Notifications, "اعلان‌ها") { sub = "notif" }
                    NavRow(Icons.Default.Lock, "امنیت و حریم خصوصی") { sub = "security" }
                    NavRow(Icons.Default.HelpOutline, "راهنما و پشتیبانی") { info = "help" }
                    NavRow(Icons.Default.Info, "درباره nonevid", "نسخه آزمایشی 1.0") { info = "about" }
                }
            }
        }
    }
    if (info.isNotEmpty()) AlertDialog(
        onDismissRequest = { info = "" },
        confirmButton = { TextButton(onClick = { info = "" }) { Text("بستن") } },
        title = { Text(if (info == "help") "راهنما و پشتیبانی" else "درباره nonevid") },
        text = {
            Text(
                if (info == "help") "پشتیبانی هنوز به سرور وصل نیست. این نسخه فقط یک نمونه‌ی اولیه است."
                else "nonevid نسخه آزمایشی 1.0. ورود، توکن‌ها و تنظیمات فقط روی همین دستگاه ذخیره می‌شوند و به هیچ سروری وصل نیستند."
            )
        }
    )
}

@Composable
fun Notifications(st: Store) {
    notifTypes.forEach { (k, t) -> SwitchRow(t, has(st.notifs, k)) { st.notifs = toggle(st.notifs, k) } }
    Text("نسخه نمایشی: فقط ترجیح شما ذخیره می‌شود و هنوز اعلان واقعی ارسال نمی‌شود.",
        Modifier.padding(16.dp), style = MaterialTheme.typography.bodySmall)
}

/** پخش را هنگام رفتن برنامه به پس‌زمینه متوقف می‌کند و هنگام بازگشت ادامه می‌دهد (شمارش پاداش هم متوقف می‌شود) */
@Composable
fun PauseOnBackground(exo: ExoPlayer) {
    val owner = LocalContext.current as ComponentActivity
    DisposableEffect(exo, owner) {
        var wasPlaying = false
        val obs = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_PAUSE) { wasPlaying = exo.playWhenReady; exo.pause() }
            else if (e == Lifecycle.Event.ON_RESUME) { if (wasPlaying) exo.play() }
        }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }
}

@Composable
fun rememberPlayerFailed(exo: ExoPlayer): State<Boolean> {
    val failed = remember(exo) { mutableStateOf(false) }
    DisposableEffect(exo) {
        val l = object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) { failed.value = true }
            override fun onPlaybackStateChanged(playbackState: Int) { if (playbackState == Player.STATE_READY) failed.value = false }
        }
        exo.addListener(l)
        onDispose { exo.removeListener(l) }
    }
    return failed
}

@Composable
fun PlayerError(modifier: Modifier = Modifier, color: Color = Color.Unspecified, onRetry: () -> Unit) {
    Column(modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("پخش ویدیو ممکن نشد. اتصال اینترنت را بررسی کنید.", color = color)
        Button(onRetry) { Text("تلاش دوباره") }
    }
}

@Composable
fun HomeScreen(st: Store, onPlay: (Movie) -> Unit) {
    var cat by remember { mutableStateOf("همه") }
    val list = movies.filter { cat == "همه" || it.cat == cat }
    Column(Modifier.fillMaxSize()) {
        Text("nonevid", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, modifier = Modifier.padding(16.dp))
        LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(cats) { c -> FilterChip(cat == c, { cat = c }, { Text(c) }) }
        }
        LazyVerticalGrid(GridCells.Fixed(2), Modifier.weight(1f), contentPadding = PaddingValues(16.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(list) { m ->
                val saved = has(st.savedIds, m.id.toString())
                Box(Modifier.fillMaxWidth().aspectRatio(0.7f).clip(RoundedCornerShape(16.dp)).background(m.color).clickable { onPlay(m) }) {
                    IconButton({ st.savedIds = toggle(st.savedIds, m.id.toString()) }, Modifier.align(Alignment.TopStart)) {
                        Icon(if (saved) Icons.Default.Bookmark else Icons.Default.BookmarkBorder, null, tint = Color.White)
                    }
                    Icon(Icons.Default.PlayCircle, null, Modifier.align(Alignment.Center).size(48.dp), tint = Color.White.copy(alpha = .8f))
                    Column(Modifier.align(Alignment.BottomStart).padding(12.dp)) {
                        Text(m.title, color = Color.White, fontWeight = FontWeight.Bold)
                        Text("${m.cat} • ${m.year}", color = Color.White.copy(alpha = .8f), style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }
}

@Composable
fun PlayerScreen(st: Store, m: Movie, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val exo = remember { ExoPlayer.Builder(ctx).build().apply { setMediaItem(MediaItem.fromUri(VIDEO_URL)); prepare(); playWhenReady = true } }
    DisposableEffect(Unit) { onDispose { exo.release() } }
    PauseOnBackground(exo)
    val failed = rememberPlayerFailed(exo)
    LaunchedEffect(Unit) {
        while (true) {
            delay(1000)
            if (exo.isPlaying && st.tick()) Toast.makeText(ctx, "🎉 $REWARD_TOKENS توکن دریافت کردید", Toast.LENGTH_LONG).show()
        }
    }
    Column(Modifier.fillMaxSize()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) }
            Text(m.title, style = MaterialTheme.typography.titleLarge)
        }
        AndroidView({ c -> PlayerView(c).also { it.player = exo } }, Modifier.fillMaxWidth().aspectRatio(16 / 9f))
        if (failed.value) PlayerError(Modifier.fillMaxWidth()) { exo.prepare(); exo.play() }
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("${m.cat} • ${m.year}", color = MaterialTheme.colorScheme.primary)
            Text(m.desc)
            Spacer(Modifier.height(8.dp))
            Text("تا پاداش بعدی", style = MaterialTheme.typography.labelLarge)
            LinearProgressIndicator(progress = { (st.watchSec % REWARD_SEC) / REWARD_SEC.toFloat() }, Modifier.fillMaxWidth())
        }
    }
}

@Composable
fun WalletScreen(st: Store) {
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text("کیف پول", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
            Column(Modifier.padding(24.dp)) {
                Text("مجموع توکن‌های دریافت‌شده")
                Text("%,d".format(st.tokens), style = MaterialTheme.typography.displayMedium, fontWeight = FontWeight.Bold)
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            StatCard("تعداد پاداش‌ها", "${st.watchSec / REWARD_SEC}", Modifier.weight(1f))
            StatCard("زمان تماشا (دقیقه)", "${st.watchSec / 60}", Modifier.weight(1f))
        }
        Text("با هر ${REWARD_SEC / 60} دقیقه تماشا، $REWARD_TOKENS توکن دریافت می‌کنید.")
        LinearProgressIndicator(progress = { (st.watchSec % REWARD_SEC) / REWARD_SEC.toFloat() }, Modifier.fillMaxWidth())
        Text("${REWARD_SEC - st.watchSec % REWARD_SEC} ثانیه تا پاداش بعدی", style = MaterialTheme.typography.bodySmall)
        Text("نسخه نمایشی: توکن‌ها فقط روی همین دستگاه ذخیره می‌شوند و ارزش واقعی ندارند.", style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
fun StatCard(t: String, v: String, mod: Modifier) = OutlinedCard(mod) {
    Column(Modifier.padding(16.dp)) { Text(t, style = MaterialTheme.typography.bodySmall); Text(v, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) }
}

@Composable
fun NavRow(icon: ImageVector, title: String, sub: String? = null, onClick: () -> Unit) = ListItem(
    headlineContent = { Text(title) },
    supportingContent = if (sub != null) ({ Text(sub) }) else null,
    leadingContent = { Icon(icon, null) },
    trailingContent = { Icon(Icons.AutoMirrored.Filled.KeyboardArrowLeft, null) },
    modifier = Modifier.clickable(onClick = onClick))

@Composable
fun SwitchRow(title: String, on: Boolean, onChange: (Boolean) -> Unit) = ListItem(
    headlineContent = { Text(title) }, trailingContent = { Switch(on, onChange) })

@Composable
fun SubPage(title: String, onBack: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    BackHandler(onBack = onBack)
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, null) }
            Text(title, style = MaterialTheme.typography.titleLarge)
        }
        content()
    }
}

@Composable
fun ProfileScreen(st: Store) {
    var sub by remember { mutableStateOf("") }
    val back = { sub = "" }
    when (sub) {
        "kyc" -> SubPage("احراز هویت", back) { Kyc(st) }
        "notif" -> SubPage("اعلان‌ها", back) { Notifications(st) }
        "security" -> SubPage("امنیت", back) { Security(st) }
        "theme" -> SubPage("تنظیمات ظاهری", back) { Appearance(st) }
        "saved" -> SubPage("فیلم‌های ذخیره‌شده", back) {
            val l = movies.filter { has(st.savedIds, it.id.toString()) }
            if (l.isEmpty()) Text("هنوز فیلمی ذخیره نکرده‌اید.", Modifier.padding(16.dp))
            l.forEach { m ->
                ListItem(headlineContent = { Text(m.title) }, supportingContent = { Text(m.cat) },
                    leadingContent = { Box(Modifier.size(40.dp).clip(CircleShape).background(m.color)) },
                    trailingContent = { IconButton({ st.savedIds = toggle(st.savedIds, m.id.toString()) }) { Icon(Icons.Default.Delete, null) } })
            }
        }
        else -> Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.AccountCircle, null, Modifier.size(64.dp), tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(12.dp))
                Column {
                    Text(st.name, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                    Text(st.phone)
                    Text(if (st.verified) "تأیید نمایشی ✅" else "هویت تأیید نشده", style = MaterialTheme.typography.bodySmall)
                }
            }
            HorizontalDivider()
            NavRow(Icons.Default.VerifiedUser, "احراز هویت", if (st.verified) "تأیید نمایشی" else "تأیید نشده") { sub = "kyc" }
            NavRow(Icons.Default.Notifications, "اعلان‌ها") { sub = "notif" }
            NavRow(Icons.Default.Lock, "امنیت") { sub = "security" }
            NavRow(Icons.Default.Palette, "تنظیمات ظاهری") { sub = "theme" }
            NavRow(Icons.Default.Bookmarks, "فیلم‌های ذخیره‌شده", "${st.savedIds.split(",").count { it.isNotEmpty() }} مورد") { sub = "saved" }
            HorizontalDivider()
            NavRow(Icons.Default.PersonAdd, "افزودن حساب") { st.loggedIn = false }
            NavRow(Icons.AutoMirrored.Filled.Logout, "خروج از حساب") { st.loggedIn = false }
        }
    }
}

@Composable
fun Kyc(st: Store) {
    val ctx = LocalContext.current
    var nc by remember { mutableStateOf("") }
    var ph by remember { mutableStateOf(st.phone) }
    var sent by remember { mutableStateOf(false) }
    var otp by remember { mutableStateOf("") }
    var err by remember { mutableStateOf<String?>(null) }
    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        if (st.verified) { Text("تأیید نمایشی انجام شد ✅ (استعلام واقعی کد ملی و شماره انجام نشده است)"); return@Column }
        Text("نسخه نمایشی: فقط فرمت کد ملی و شماره بررسی می‌شود و به سرویس رسمی استعلام وصل نیست.")
        OutlinedTextField(nc, { nc = it.take(10) }, label = { Text("کد ملی") }, singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
        OutlinedTextField(ph, { ph = it.take(11) }, label = { Text("شماره تماس") }, singleLine = true,
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone), modifier = Modifier.fillMaxWidth())
        err?.let { Text(it, color = MaterialTheme.colorScheme.error) }
        if (!sent) {
            Button({
                err = when {
                    !validNationalCode(nc) -> "کد ملی معتبر نیست"
                    !validPhone(ph) -> "شماره تماس معتبر نیست"
                    else -> null
                }
                // TODO: اینجا باید سرویس استعلام تطبیق کد ملی و شماره (مثل شاهکار از طریق ارائه‌دهنده‌ی مجاز) صدا زده شود
                if (err == null) { sent = true; Toast.makeText(ctx, "کد دمو: 12345", Toast.LENGTH_LONG).show() }
            }, Modifier.fillMaxWidth()) { Text("ارسال کد تأیید") }
        } else {
            OutlinedTextField(otp, { otp = it.take(5) }, label = { Text("کد پیامک‌شده") }, singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), modifier = Modifier.fillMaxWidth())
            Button({ if (otp == "12345") st.verified = true else err = "کد اشتباه است" }, Modifier.fillMaxWidth()) { Text("تأیید هویت") }
        }
    }
}

@Composable
fun Security(st: Store) {
    val ctx = LocalContext.current
    var dialog by remember { mutableStateOf(false) }
    var p by remember { mutableStateOf("") }
    SwitchRow("قفل برنامه با رمز ۴ رقمی", st.pinOn) { if (it) { p = ""; dialog = true } else { st.pinOn = false; st.pin = "" } }
    if (st.pinOn) NavRow(Icons.Default.Password, "تغییر رمز") { p = ""; dialog = true }
    SwitchRow("تأیید دو مرحله‌ای (نمایشی، هنوز اعمال نمی‌شود)", st.twoStep) { st.twoStep = it }
    SwitchRow("جلوگیری از اسکرین‌شات و ضبط صفحه", st.secureScreen) { st.secureScreen = it }
    NavRow(Icons.Default.Devices, "خروج از سایر دستگاه‌ها") { Toast.makeText(ctx, "نسخه نمایشی: داده‌ها فقط روی همین دستگاه هستند", Toast.LENGTH_SHORT).show() }
    if (dialog) AlertDialog(onDismissRequest = { dialog = false }, title = { Text("رمز ۴ رقمی جدید") },
        text = {
            OutlinedTextField(p, { p = it.filter(Char::isDigit).take(4) }, singleLine = true,
                visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword))
        },
        confirmButton = { TextButton({ if (p.length == 4) { st.pin = hashPin(p); st.pinOn = true; dialog = false } }) { Text("ذخیره") } },
        dismissButton = { TextButton({ dialog = false }) { Text("انصراف") } })
}

@Composable
fun Appearance(st: Store) {
    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("حالت نمایش", style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("سیستم", "روشن", "تیره").forEachIndexed { i, t -> FilterChip(st.themeMode == i, { st.themeMode = i }, { Text(t) }) }
        }
        Text("رنگ اصلی برنامه", style = MaterialTheme.typography.titleMedium)
        LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            items(accents) { c ->
                val col = Color(c)
                Box(Modifier.size(44.dp).clip(CircleShape).background(col).clickable { st.accent = col.toArgb() },
                    contentAlignment = Alignment.Center) {
                    if (st.accent == col.toArgb()) Icon(Icons.Default.Check, null, tint = Color.White)
                }
            }
        }
        SwitchRow("پس‌زمینه‌ی کاملاً مشکی (AMOLED) در حالت تیره", st.amoled) { st.amoled = it }
    }
}
